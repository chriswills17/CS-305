/******************************************************************
** 
** CS-305 Project 2
** SslServerApplication.java
** 
** Chris Wills
** Southern New Hampshire University
** CS-305-T3311 Software Security
** Dr. Vivian Lyon
** February 19, 2023
**
******************************************************************/

package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController 
class SslServerController {
	
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		// Sample data and name
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		String data = "Hello World Check Sum!";
		String name = "Chris Wills";
		
		// Split the name and get the first and last name
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		String[ ] splitname = name.split(" ");
		String firstname = splitname [0];
		String lastname = splitname[splitname.length - 1];
		
		// Check if there is more than one name
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		if (splitname.length > 1) {
			// If there is more than one name, concatenate the first and last name
			name = firstname + " " + lastname;
		}
		
		// Generate SHA-256 hash for the name
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] shavalue = md.digest(name.getBytes(StandardCharsets.UTF_8));
		
		// Create response using StringBuilder to improve performance
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		StringBuilder response = new StringBuilder();
		response.append("Data: ").append(data).append("</br></br>");
		response.append("Name: ").append(name).append("</br></br>");
		response.append("Name of algorithm used: SHA-256 CheckSum Value: ").append(bytesToHex(shavalue));
		
		// Convert StringBuilder to String and return the response
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		return response.toString();
	}
	
	// Method to convert byte array to hexadecimal string
	//Wills, C. (2023). 7-2 Project [Unpublished
	//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
	public String bytesToHex(byte[] sha256) {
		BigInteger hex = new BigInteger(1, sha256);
		StringBuilder checksum = new StringBuilder(hex.toString(16));
		
		// Pad with leading zeros if necessary
		//Wills, C. (2023). 7-2 Project [Unpublished
		//assignment submitted for CS-305-T3311]. Southern New Hampshire University.
		while (checksum.length() < 32) {
			checksum.insert(0, '0');
		}
		
		return checksum.toString();
	}
}
